/*
Comparison Operator: ==, ===, !=, !==, >, <, >=, <=

The comparison operators are used to compare two values.
For example:
var x = 5;
var y = 10;
x == y; // false
x === y; // false
x != y; // true
x !== y; // true
x > y; // false
x < y; // true
x >= y; // false
x <= y; // true
*/

console.log("equal check:", 2 == 2); //true
console.log("srick euqal : ", 2 === 2); //true
console.log("srick euqal : ", 2 === "2"); //true
console.log("not equal check::", 2 != 5);
console.log("greate number:",  2 > 5); //false
console.log("greate number:",  2 < 5); //false
console.log("greate number or equal to:",  2 >= 5); //false
console.log("less number or equal to:",  2 <= 5); //true