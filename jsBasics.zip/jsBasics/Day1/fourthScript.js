/*
Arithmetic Operators in JavaScript:

1. Addition (+) : 2+2 = 4
2. Subtraction (-) : 2-2 = 0
3. Multiplication (*) : 2 * 2 = 4
4. Division (/) : 2/2  = 1
5. Modulus (%) : 2%2 = 0
6. ++ : increment by 1
7. -- : decrement by 1
8. Exponentiation (**) : 2**2 = 4

*/

var x = 5;
// console.log(5+5);
//i want a add a message + the result 
console.log("addtion output is : ", x+5);

console.log("subtraction ouput is : ", x=2);

console.log("multiplication output is : ", x*2);

console.log("division output is : ", x/2);

console.log("modulus output is : ", x%2);

console.log("increment operation: " , ++x);
console.log("decrement operation: " , --x);
console.log("exponentiation output is : ", x**2);
