/*
Logical Operator: &&, || & !

exp1 : true 
exp2: true 
&& : both expressions shuld return true, if one expression : 
|| : anyone expressiion is true the outcome is going to be true

exp1     exp2.   exp1 && exp2.  exp1 || exp2
true     true      true          true
true     false     false         true
false    true      false         true
false    false     false         false


exp1 && exp2 :: true 
*/

console.log((2>2) && (2>5)); //false
console.log((2>2) || (12>5)); //true
console.log(!(2>2)); //true

var firstName = "Surendra";
var lastName = "Jaganadam";

console.log(firstName + " " + lastName);