var empName = "surendra jaganadam";
let empID = 1001;

console.log(empID);
console.log("************")

var empDept, empSalary;
let num1=10, num2=20, num3= 40;
empDept = "Development";
empSalary = 5000;

empID = 10001;

console.log(empName);
console.log(empID);
console.log(empDept);
console.log(empSalary);
console.log(num1);
console.log(num2);
console.log(num3);

// This is a single line comment
/*
var: older versions of JS , function scoped 
let: new way of declaring variables, block scoped
letter , _ , $ : allowedin variable names, meaninful name , no spaces, no specical characters & also no numbers in the strating of the varibale
*/