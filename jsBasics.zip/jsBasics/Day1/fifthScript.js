/*
Assignment Operator: =

The assignment operator is used to assign a value to a variable.
For example:
var x = 5; // assigns the value 5 to the variable x
+= , x = x+5(we are adding 5 to x and storing into x vrible itself) , x+=5 , x= x+5
x = x+5 or x+=5 both are same
-= x=x-1 or x-=1
*=
/=
%=
**=
*/
var x = 10;
console.log("increment and print: ", x+=5); // x = x + 5
console.log("decrement and print: ", x-=2); // x = x - 2
console.log("multiplication and print: ", x*=2); // x = x * 2
console.log("division and print: ", x/=2); // x = x / 2
console.log("modulus and print: ", x%=2); // x = x % 2
console.log("exponentiation and print: ", x**=2); // x = x ** 2