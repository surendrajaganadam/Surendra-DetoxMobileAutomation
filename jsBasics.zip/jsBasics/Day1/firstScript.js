console.log("Hello, Surendra Jaganadam!");
console.log(5000);

/*
constant : type of variable whose value cannot be changed

*/

const empLocation = "Hyderabad";
console.log(empLocation);

empLocation = "Bangalore"; // This will throw an error
console.log(empLocation);