/*
Datatype: represents the type of data that can be stored in a variable
1. Primitive Datatypes: number, string, boolean, null, undefined, symbol : 1 value at a time
2. Reference Datatypes: object, array, function : multiple values


String: represents a sequence of characters, used for storing text , single quote or double quote also
'surendra' or "surendra" / 'surendra" 
number: represents both integer and floating point values : 3, 3.4
boolean: represents only two values: true or false
null: denotes a null value into a variable
undefined: denotes a variable that has been declared but has not yet been assigned a value

*/

var empName = "Surendra Jaganadam";
console.log(empName);

var empID = 101;
console.log(empID);

var empSalary= 50000.99;
console.log(empSalary);

var numberCheck = 100 / 0;
console.log(numberCheck);

var numberCheck1 = -100 / 0;
console.log(numberCheck1);

var numberCheck2 = "abc" / 3;
console.log(numberCheck2);

var empLogedIn = true;
console.log(empLogedIn);

var empResigned;
console.log(empResigned);

var empDesignation = null;
console.log(empDesignation);

console.log("***********************");
console.log(typeof(empName));
console.log(typeof(empID));
console.log(typeof(empSalary));
console.log(typeof(numberCheck));
console.log(typeof(numberCheck1));
console.log(typeof(numberCheck2));
console.log(typeof(empLogedIn));
console.log(typeof(empResigned));
console.log(typeof(empDesignation));
