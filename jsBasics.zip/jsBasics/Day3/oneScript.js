/*
overview on arrays with examples:
Array is an object that can store multiple value at a time
var name1 = "John";
var name2 = "Jane";
var name3 = "Doe";
var names = [name1, name2, name3];
var stuNames = ["John", "Jane", "do ];

index based operations we can perform using this array 
0th index --> 1sy value 
1st index --> 2nd vaue 
2nd index --> 3rd value in the array

*/

var empNames = ["John", "Jane", "Doe"];
console.log(empNames);
console.log(empNames[0]);
console.log(empNames.length);
//push & unshift : to add values to an aray
empNames.push("radha");
empNames.unshift("krishna");


//chgange 2nd valkuye in the array
empNames[1] = "Ramesh";
console.log(empNames);

//remove an element or value from the array
empNames.pop(); //removed at the end
console.log(empNames);
empNames.shift(); //removed at the beginning
console.log(empNames);

//splice : remove at a specific index
empNames.splice(1, 1);
console.log(empNames);