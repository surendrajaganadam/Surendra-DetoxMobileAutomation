var empNames = ["John", "Jane", "Doe"];
/*
.length : to get the length of an array
arryname[index] ==> that index value
*/

// for(var i=0; i<empNames.length;i++){
// console.log(empNames[i]);
// }

/*
forEach loop: calls function and iterate that funciton logic on all the elemnts present in that array
array.forEach(function());



*/


function printData(name){
console.log("Employee Name: "+name);
}


empNames.forEach(printData);