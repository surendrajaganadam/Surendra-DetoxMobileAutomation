/*
class : 
ur requiremnt to construct a house ?? plan blueprint

example: ABC Engg College
Ramsh: EEE
Mahesh: IT
suresh: ECE

exam application form ??? common for the people who r studying : blueprint

class classname {
body of the class

method --> a class method is a function insde a class
after calss n methods got created ew will create an object n we will access the informataion present in the class
}



*/

class stuDetails{


greetingMessage(name){
console.log("Hello " + name + ", welcome to the class!");
}


}

//we need to creaet an object to that class
var stu1 = new stuDetails();

stu1.greetingMessage("Ramsh");

