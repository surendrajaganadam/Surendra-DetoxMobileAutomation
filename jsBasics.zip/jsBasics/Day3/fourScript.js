class stuDetails{

// constructor(){
// console.log("default consturctor")
// }

constructor(uname, salary){
console.log(uname + " your salary is " + salary);
}

greetingMessage(name){
console.log("Hello " + name + ", welcome to the class!");
}


}

var stu1 = new stuDetails("ramya", 45000);



