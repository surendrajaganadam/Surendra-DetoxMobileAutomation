sum(10,20);

function sum(a,b){
console.log(a+b);
}

/*
arrow function: 
var function = () ==> expression

*/
var demoHello= () => console.log("heloo arrow function");

demoHello();

var demoSubtraction = a => console.log("arrow subtraction output: " + (a-10));
demoSubtraction(20);

var demoSum =(a,b) => console.log("arrow sum output: " + (a+b));

demoSum(10,20);

/*
sum is the name of the funciton
anonymus function: a function without a name

*/



var helloWorld = function(){
    console.log("Hello World Anonymous User");
}

helloWorld();

