/*
variable has multiple values and at time only 1 value will be used 
based on the variable value we need to execute some set of logics
in such cases we use this switch case

switch(variable){
    case value1:
        // logic for value1
        break;
    case value2:
        // logic for value2
        break;
    default:
        // logic for other values
}

day --> Monday , Tuesday , Wednesday, Thursday, Friday, Saturday, Sunday

*/

var day = "Thursday";

switch(day){
case "Monday":
 console.log("1st day of the week");
 
 case "Tuesday":
 console.log("2nd day of the week");
 
 case "Wednesday":
 console.log("3rd day of the week");
 
 case "Thursday":
 console.log("4th day of the week");
 
 case "Friday":
 console.log("5th day of the week");
 
 case "Saturday":
 console.log("6th day of the week");
 
 case "Sunday":
 console.log("7th day of the week");
 
 default: 
 console.log("Not a valid day");
}

// switch(day){
// case "Monday":
//  console.log("1st day of the week");
//  break;
//  case "Tuesday":
//  console.log("2nd day of the week");
//  break;
//  case "Wednesday":
//  console.log("3rd day of the week");
//  break;
//  case "Thursday":
//  console.log("4th day of the week");
//  break;
//  case "Friday":
//  console.log("5th day of the week");
//  break;
//  case "Saturday":
//  console.log("6th day of the week");
//  break;
//  case "Sunday":
//  console.log("7th day of the week");
//  break;
//  default: 
//  console.log("Not a valid day");
// }