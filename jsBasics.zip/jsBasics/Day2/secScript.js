/*
syntax for for loop:
for(initialization; condition; increment/decrement){
   // code to be executed
}

write a program that will be printing numebrs from 1 to 100 all even numbers
even number :: %2==0
i%2 == 0 then it is an even number 

*/

// for(var i=1;i<=100;i++){
// console.log("surendra");
// console.log(i);
// }

// for(var i=101;i<=100;i++){
// console.log("surendra");
// console.log(i);
// }

// for(var i=101;true;i++){
// console.log("surendra");
// console.log(i);
// }

// for(var i=1;i<=5;i++){
// console.log("surendra", i);
//  for(var j=10;j<=15;j++){
// console.log("jaganadam", j);
// }
// }

// for(var i=1;i<=100;i++){
// if(i%2==0){
// console.log(i);
// }

// }
