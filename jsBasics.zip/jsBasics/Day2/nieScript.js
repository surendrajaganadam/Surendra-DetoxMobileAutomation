/*
if u want to store something in a key and value pair in such cases use these objects
ideally thee we call them as properties and we can access the value assioted using those keys 

var bjectName = {
key1: value1,
key2: value2,

optionally we can add function also
}
*/

var empDetails = {
empId: 101,
empName: "surendra",
}

var stuDetails = {
stuId: 201,
stuName: "John",

greet: function(){
    console.log("Hello, my name is " + this.stuName);
}
}

stuDetails.greet();

// console.log(empDetails.empId);
// console.log(empDetails['empName']);

// empDetails.empId = 201; //updating the value
// console.log(empDetails.empId);

// empDetails.empSalary = 45000;
// console.log(empDetails);

// delete empDetails.empSalary;
// console.log(empDetails);