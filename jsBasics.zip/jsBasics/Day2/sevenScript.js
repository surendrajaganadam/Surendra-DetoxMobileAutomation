function sum(a,b){
console.log(a+b);
}

function subtraction(a,b){
return a-b;
}


// sum(10,20);
var result = subtraction(30,10);
console.log(result);

/*
task: goto grocessory mark n bring 1kg sugar
2 appraoches: 
1. goto store, pick sugar, pay money, come back
2. goto store, pick sugar, also take choclates , comeback

function &function with return stmt both performs actions for sure
only difference is fucniton with return stmt will give someout which we can use where we are calling it

function
builtin functions



*/