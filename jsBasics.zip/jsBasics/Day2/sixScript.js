/*

D1: create user : login, create, logout
D2: update user: login, update, logout
D3: delete user: login, delete, logout

we can create a function for Login, logout where others can simply reuse that logic
1 person is creating the logic & other persons are reusing that logic

syntax:
fucntion name() {
   // logic
}
*/

function greetingMessage(){
console.log("Hello User, Welcome to our application");
}

// greetingMessage();

function greet(name){
console.log("Hello " + name + ", Welcome to our application");
}

greet("surendra");
greet("ramya");
greet("sneha");
