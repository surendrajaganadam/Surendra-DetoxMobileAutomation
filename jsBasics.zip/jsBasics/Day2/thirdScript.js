/*
syntax for while loop:
while(condition){
   // code to be executed
}

do-while loop: 
do{
   // code to be executed
}while(condition);

while : entry checked
do-while: exit checked                                                                                                    
*/

var x = 10;
do{
   console.log(x);
   x++;
}while(x<=5);

// while(x<=5){
// console.log(x);
// x++;
// }

// while(x<=5){
// console.log(x);
// x++;
// }

// while(x<=100){
// if(x%2===0){
// console.log(x);
// }
// x++;
// }