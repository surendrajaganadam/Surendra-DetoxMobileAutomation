/*
overview on break & continue:
break: used to exit a loop or switch statement
continue: used to skip the current iteration of a loop and move to the next iteration

*/

for(var i=1;i<=10;i++){
if(i==4 || i==7 || i==9){
continue;
}
console.log(i);

}

// for(var i=1;i<=10;i++){

// if(i == 5){
// break;
// }
// console.log(i);

// }