/*

Conditional Statements: 
if(condition){
logic present inside th block wll be executed 
}

if(condition){
block will be executed
}else{
Overview on Operators with examples Part 1
}

*/

var a=5, b=20, c=10;


// if(a >b && a>c){
//    console.log("A is the greatest");
// }else if(b > a && b > c){
//    console.log("B is the greatest");
// }else if(c > a && c > b){
//    console.log("C is the greatest");
// }
var stuMarks = 94;
var mathMarks = 98;

if(stuMarks >= 90){
console.log("Grade A");

if(mathMarks>95){
console.log("student is excellent in maths")
}

}


// if(a >b && a>c){
//    console.log("A is the greatest");
// }else if(b > a && b > c){
//    console.log("B is the greatest");
// }else{
//    console.log("C is the greatest");
// }



// var empID= 11;
// if(empID > 100){
//    console.log("Employee ID is greater than 100");
// }else{
// console.log("Employee ID is less than or equal to 100");
// }